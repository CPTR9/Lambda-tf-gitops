import json

def lambda_handler(event, context):
    # Log the incoming event for debugging purposes
    print("Received event:", json.dumps(event, indent=2))

    # Process the event (this is a placeholder for your logic)
    response = {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Hello from Lambda!",
            "input": event
        })
    }

    return response